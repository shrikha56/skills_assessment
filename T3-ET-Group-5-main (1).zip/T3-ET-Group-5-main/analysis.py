#import pandas and matplotlib
import pandas as pd
import matplotlib.pyplot as plt

#load the csv file
wildfire_data = pd.read_csv('/Users/shrikha/Downloads/wildfire_dataset.csv')

#print first 5 rows
print("First 5 rows:")
print(wildfire_data.head())

#calculate total acres burned
total_acres_burned = wildfire_data["Acres_Burned"].sum()
print(f"Total Acres Burned: {total_acres_burned}")

#calculate average population affected
average_population_affected = wildfire_data["Population_Affected"].mean()
print(f"Average Population Affected: {average_population_affected:.2f}")

#fix distance column by removing 'km'
wildfire_data["Distance_to_Resources"] = wildfire_data["Distance_to_Resources"].str.replace(" km", "").astype(int)
average_distance = wildfire_data["Distance_to_Resources"].mean()
print(f"Average Distance to Resources (km): {average_distance:.2f}")

#count fire severity levels
severity_counts = wildfire_data['Fire_Severity'].value_counts()
print("\nFire Severity Counts:")
for severity, count in severity_counts.items():
    print(f"{severity}: {count}")

#create bar chart for fire severity
plt.figure(figsize=(10, 6))
plt.bar(severity_counts.index, severity_counts.values)
plt.title('Fire Severity Distribution')
plt.xlabel('Severity Level')
plt.ylabel('Number of Fires')
plt.savefig('fire_severity_bar.png')
plt.show()

#create pie chart for fire severity
plt.figure(figsize=(8, 8))
plt.pie(severity_counts, labels=severity_counts.index, autopct='%1.1f%%')
plt.title('Fire Severity Distribution')
plt.savefig('fire_severity_pie.png')
plt.show()

#create bar chart for acres burned by severity
plt.figure(figsize=(10, 6))

#calculate average acres by severity
acres_by_severity = wildfire_data.groupby('Fire_Severity')['Acres_Burned'].mean()

#plot the bar chart
plt.bar(acres_by_severity.index, acres_by_severity.values)
plt.title('Average Acres Burned by Fire Severity')
plt.xlabel('Fire Severity')
plt.ylabel('Average Acres Burned')
plt.savefig('acres_by_severity.png')
plt.show()

#print key insights
print("\nKey Insights:")
print(f"1. Most common fire severity level: {severity_counts.idxmax()}")
print(f"2. Total acres burned: {total_acres_burned}")
print(f"3. Average population affected: {average_population_affected:.2f}")
